import { React, useState } from "react";
import "../App.css";


function Footer() {
  return (
    <>
      <footer className="footer">
        <footer className="Footer">
          <div className="footerDiv">
            <div className="footerP">
              Tel. číslo: 789 456 123 <br />
              Email: contact@strnad.dev
            <div className="imageDiv">
                <img src="../public/khLogo.svg"/>
            </div>

            <p className="fninder">
                FŇINDER
            </p>
            </div>
          </div>
        </footer>
      </footer>
    </>
  );
}

export default Footer;
