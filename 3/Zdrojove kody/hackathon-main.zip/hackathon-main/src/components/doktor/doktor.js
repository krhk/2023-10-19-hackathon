import React from "react";

export const Doktor = (props) => {    

  return (
    <div className="cardDoctor" key={props.id}>
      <div className="nazevDoktor">{props.nazev}</div>
      <div className="nazevObce">{props.nazev_obce}, {props.psc}</div>
      <div className="nazevUlice">{props.nazev_ulice}</div>
      <div className="ordinacniHodiny">{props.ordinacni_hodiny}</div>
      <a className="wwwStranka" href={props.www} target="_blank">WEB</a>      
      {/* Add other components here */}
    </div>
  );
};