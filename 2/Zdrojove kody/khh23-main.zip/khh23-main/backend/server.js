require("dotenv").config();

const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");

const PORT = process.env.PORT;
const HOST = process.env.HOST;
const DB_CONNECTION = process.env.DB_CONNECTION;



// CORS
app.use(cors());

// Parse JSON
app.use(bodyParser.json());

// Import routes
const oborRoute = require("./routes/obory.js");
const zastavkaRoute = require("./routes/zastavky.js");
const skolaRoute = require("./routes/skoly.js")

// Use routes
app.use("/obory", oborRoute);
app.use("/zastavky", zastavkaRoute);
app.use("/skoly", skolaRoute);


app.get("/*", (req, res) => {
	res.send("404 Not Found");
});

app.listen(PORT, HOST, () => {
	console.log(`Server is running on http://${HOST}:${PORT}`);
	mongoose
		.connect(DB_CONNECTION, { useNewUrlParser: true })
		.then(() => console.log("Connected to MongoDB!"))
		.catch((error) => console.error("Error connecting to MongoDB", error));
});
