import { React, useState } from 'react'
import HomePageComp from '../components/Home_Page'
import Header from '../components/Header';
import Footer from '../components/Footer';

function HomePage() {

  return (
    <>
    <Header/>
    <HomePageComp/>
    <Footer/>
    </>
  )
}

export default HomePage;
