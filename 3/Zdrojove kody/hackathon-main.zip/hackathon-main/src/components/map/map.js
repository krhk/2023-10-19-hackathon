import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import "./map.css";
import { useData } from "../data/data";
import { Icon } from "leaflet";
import MarkerClusterGroup from "react-leaflet-cluster";

export const Map = () => {
  const d = useData();
  const markers = d.slice(0, d.length / 2);
  console.log(markers);
  const customIcon = new Icon({
    iconUrl: require("../icons/hospital.png"),
    iconSize: [38, 38],
  });

  return (
    //praha [50.073658, 14.41854]
    <MapContainer center={[50.1983, 15.8285]} zoom={13}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      <MarkerClusterGroup>
        {markers.map((marker) => (
          <Marker position={marker.geocode} icon={customIcon}>
            <Popup>{marker.nazev}</Popup>
          </Marker>
        ))}
      </MarkerClusterGroup>

      {/* <Marker position={[50.430126, 15.812337]}>
       
      </Marker> */}
    </MapContainer>
  );
};
