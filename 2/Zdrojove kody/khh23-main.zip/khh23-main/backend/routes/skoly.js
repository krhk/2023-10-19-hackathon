const express = require("express");
const router = express.Router();
const School = require("../models/school_model");

router.get("/:query", async (req, res) => {
	const query = req.params.query;
	const regex = new RegExp(`^${query}`, "i");

	try {
		const results = await School.find({ nazev: regex });
		return res.json(results);
	} catch (err) {
		return res.json({ message: err.toString() });
	}
});

module.exports = router;
