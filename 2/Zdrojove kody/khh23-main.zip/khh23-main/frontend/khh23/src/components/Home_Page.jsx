import React, { useState, useEffect } from "react";
import "../App.css";
import axios from "axios";

function HomePageComp() {
  const [data, setData] = useState([]);
  const [data2, setData2] = useState([]);
  const [selectedBusStop, setSelectedBusStop] = useState("");
  const [selectedObor, setSelectedObor] = useState("");



  let config = {
    method: 'post',
    maxBodyLength: Infinity,
    url: 'http://localhost:3000/obory/vysledek',
    headers: { }
  };
   
  



  const fetchUserData = () => {
    fetch("http://localhost:3000/zastavky/")
      .then((response) => response.json())
      .then((xxx) => {
        setData(xxx);
      });
  };

  const fetchUserDataOb = () => {
    fetch("http://localhost:3000/obory/")
      .then((response) => response.json())
      .then((yyy) => {
        setData2(yyy);
      });
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  useEffect(() => {
    fetchUserDataOb();
  }, []);

  const handleBusStopChange = (event) => {
    setSelectedBusStop(event.target.value);
  };

  const handleOborChange = (event) => {
    setSelectedObor(event.target.value);
  };

  const handleSearch = () => {
    
      axios.request(config)
      .then((response) => {
        console.log(JSON.stringify(response.data));
      })
      .catch((error) => {
        console.log(error);
      });
    
 

  };

  return (
    <>
      <section className="HomePage">
        <form>
          <div className="HPDiv">
            <img src="./public/school.svg" className="hat" alt="school" />
            <h1 className="mainText">
              Vyhledej svoji <b>vysněnou</b> školu!
            </h1>
            <label className="HPLabel">Zastávka: </label>
            <br />
            {data.length > 0 && (
              <select
                id="busStop"
                type="text"
                className="Select"
                value={selectedBusStop}
                onChange={handleBusStopChange}
              >
                <option value="">Vyber zastávku</option>
                {data.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            )}
            <br />
            <br />
            <label className="HPLabel">Obor: </label>
            <br />
            {data2.length > 0 && (
              <select
                id="obor"
                type="text"
                className="Select"
                value={selectedObor}
                onChange={handleOborChange}
              >
                <option value="">Vyber obor</option>
                {data2.map((option, index) => (
                  <option key={index} value={option.obor_nazev}>
                    {option.obor_nazev}
                  </option>
                ))}
              </select>
            )}
            <br />
            <br />
            <button className="HPButton" type="button" onClick={handleSearch}>
              Hledat!
            </button>
          </div>
        </form>
      </section>
    </>
  );
}

export default HomePageComp;
