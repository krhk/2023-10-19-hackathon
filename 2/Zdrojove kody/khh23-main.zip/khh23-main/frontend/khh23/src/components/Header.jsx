import React, { useState, useEffect } from "react";
import "../App.css";

function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);

  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // Add a state to track the visibility of the dropdown menu
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  // Function to toggle the dropdown menu
  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  };

  // Define a condition for when to show the dropdown menu
  const showDropdown = windowWidth <= 450;

  return (
    <>
    <link rel="stylesheet" href="https://unpkg.com/swiper@7.4.1/swiper-bundle.min.css"/>
      <header className="header">
        <a><b>
          <span className="logo">FŇINDER</span></b>
        </a>
        {showDropdown ? (
          // Button for the hamburger menu
          <button id="menu-btn" onClick={toggleDropdown}>
            <i className={`fas ${isDropdownVisible ? "fa-times" : "fa-bars"}`}></i>
          </button>
        ) : (
          // Display the menu as a row of links when the screen width is larger
          <div id="menu">
            <nav className={`navbar ${isDropdownVisible ? "active" : ""}`}>
              <a href="#">Vyhledat školu</a>
              <a href="#">Jak na to</a>
              <a href="#">Tipy</a>
              <a href="#">Kontakty</a>
            </nav>
          </div>
        )}
      </header>
    </>
  );
}

export default Header;