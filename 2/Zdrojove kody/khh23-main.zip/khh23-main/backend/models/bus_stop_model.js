const mongoose = require("mongoose");

const BusSchema = mongoose.Schema({
    ObjectID: {
        type: String,
    },
    nazev: {
        type: String,
    },
    oznaceni: {
        type: String,
    },
    nazev_vusc: {
        type: String,
    },
    kod_vusc: {
        type: String,
    },
    kod_orp: {
        type: String,
    },
    nazev_okresu: {
        type: String,
    },
    kod_okresu: {
        type: String,
    },
    nazev_obce: {
        type: String,
    },
    kod_obce: {
        type: String,
    },
    wkt: {
        type: String,
    },
    x: {
        type: Number,
    },
    y: {
        type: Number,
    },
    dp_id: {
        type: String,
    },

});

module.exports = mongoose.model("Stops", BusSchema);
