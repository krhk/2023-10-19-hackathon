import React from "react";
import { useData } from "../data/data";
import { Doktor } from "../doktor/doktor";

export const Doktori = (props) => {
  const searchText = props.search;
  const d = useData();
  let data = d.slice(0, d.length / 2);

  if (props.typ !== "") {
    data = data.filter((doktor) => doktor.nazev.includes(props.typ));
  }
  return data.map((doktor) => {
    if (
      doktor.nazev.includes(searchText) ||
      doktor.nazev_obce.includes(searchText)
    ) {
      return (
        <Doktor
          id={doktor.id}
          nazev={doktor.nazev}
          nazev_obce={doktor.nazev_obce}
          psc={doktor.psc}
          nazev_ulice={doktor.nazev_ulice}
          ordinacni_hodiny={doktor.ordinacni_hodiny}
          www={doktor.www}
        />
      );
    } else return "";
  });
};
