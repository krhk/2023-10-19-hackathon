const express = require("express");
const router = express.Router();
const BusStop = require("../models/bus_stop_model");
const School = require("../models/school_model");
const nearbySort = require("nearby-sort");

router.get("/:query", async (req, res) => {
  const query = req.params.query;
  const regex = new RegExp(`^${query}`, "i");

  try {
    const result = await BusStop.distinct("nazev", { nazev: regex });

    return res.json(result);
  } catch (err) {
    res.json({ message: err.toString() });
  }
});

router.get("/", async (req, res) => {
  try {
    const result = await BusStop.distinct("nazev");

    return res.json(result);
  } catch (err) {
    res.json({ message: err.toString() });
  }
});

router.post("/:query", async (req, res) => {
  const station = await BusStop.findOne({ nazev: req.params.query });

  const coordinates = {
    lat: station.y,
    long: station.x,
  };

  const school = await School.find();

  const modifiedSchool = school.map((data) => ({
    nazev: data.nazev,
    lat: data.y,
    long: data.x,
  }));

  let ascSortedData = await nearbySort(coordinates, modifiedSchool);

  return res.json(ascSortedData);
});

module.exports = router;
