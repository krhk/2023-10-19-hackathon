const express = require("express");
const router = express.Router();
const School = require("../models/school_model");


router.get("/:query", async (req, res) => {
  const query = req.params.query;
  const regex = new RegExp(`^${query}`, "i"); 

  try {
    const result1 = await School.find({ obor_nazev: regex });
    const result2 = await School.find({ obor_kod: regex });

    // Merge the two results
    const result = [...result1, ...result2];

    return res.json(result);
  } catch (err) {
    res.json({ message: err.toString() });
  }
});




module.exports = router;
