import React, { useEffect, useState } from "react";

export const useData = () => {
  const [data, setData] = useState([]);
  const url1 =
    "https://services6.arcgis.com/ogJAiK65nXL1mXAW/arcgis/rest/services/L%C3%A9ka%C5%99sk%C3%A1_pohotovostn%C3%AD_slu%C5%BEba/FeatureServer/0/query?outFields=*&where=1%3D1&f=json";
  const url2 =
    "https://services6.arcgis.com/ogJAiK65nXL1mXAW/arcgis/rest/services/Prakti%C4%8Dt%C3%AD_l%C3%A9ka%C5%99i_pro_dosp%C4%9Bl%C3%A9/FeatureServer/0/query?outFields=*&where=1%3D1&f=json";
  const url3 =
    "https://services6.arcgis.com/ogJAiK65nXL1mXAW/arcgis/rest/services/Zubn%C3%AD_l%C3%A9ka%C5%99i/FeatureServer/0/query?outFields=*&where=1%3D1&f=json";

  const fetchData = async (url) => {
    try {
      const response = await fetch(url);

      if (response.ok) {
        const result = await response.json();
        setData((prevData) => [...prevData, ...result.features]);
      } else {
        console.error("Failed to fetch data");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData(url1);
  }, []);

  useEffect(() => {
    fetchData(url2);
  }, []);

  useEffect(() => {
    fetchData(url3);
  }, []);

  console.log(data);
  return data.map((features, index) => {
    const { attributes } = features;

    return {
      id: index,
      geocode: [attributes?.y, attributes?.x],
      nazev: attributes?.nazev || attributes?.provozovatel,
      nazev_obce: attributes?.nazev_obce,
      nazev_okresu: attributes?.nazev_okresu,
      nazev_ulice: attributes?.nazev_ulice,
      ordinacni_hodiny: attributes?.ordinacni_hodiny,
      psc: attributes?.psc,
      www: attributes?.www,
    };
  });
};
