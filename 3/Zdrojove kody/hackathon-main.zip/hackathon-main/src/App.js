import React, { useState } from "react";
import "./App.css";
import { Doktori } from "./components/doktori/doktori";
import { Map } from "./components/map/map";

function App() {
  const [typDoktora, setTypDoktora] = useState("");

  const [inputText, setInput] = useState("");
  const [searchText, searchInput] = useState("");

  const handleInputChange = (event) => {
    setInput(event.target.value);
  };

  const handleCheckboxDoktori = () => {
    if (typDoktora === "praktického") {
      setTypDoktora("");
    } else {
      setTypDoktora("praktického");
    }
  };
  const handleCheckboxZubari = () => {
    if (typDoktora === "zubní") {
      setTypDoktora("");
    } else {
      setTypDoktora("zubní");
    }
  };

  const handleCheckboxPohotovost = () => {
    if (typDoktora === "nemocnice") {
      setTypDoktora("");
    } else {
      setTypDoktora("nemocnice");
    }
  };

  const vyfiltruj = () => {
    searchInput(inputText);
  };

  return (
    <div className="App">
      <div className="Menu">
        <div className="a"><Doktori search={searchText} typ={typDoktora} /></div>
        <div className="b"><Map /></div>
        <div className="Header">
          <div className="searchCity">
            <input type="text" onChange={handleInputChange}></input>
            <button onClick={vyfiltruj}>Vyhledej</button>
            </div>
            <div className="filterDoktor">
              <div className="praktictiCheck">
              Praktičtí lékaři
                <input type="checkbox" onClick={handleCheckboxDoktori}></input>
                
              </div>
              <div className="zubariCheck">
              Zubaři
                <input type="checkbox" onClick={handleCheckboxZubari}></input>
                
              </div>
              <div className="pohotovostCheck">
              Pohotovost
                <input type="checkbox" onClick={handleCheckboxPohotovost}></input>
                
              </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
