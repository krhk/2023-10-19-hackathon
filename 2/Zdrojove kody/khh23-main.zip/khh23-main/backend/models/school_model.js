const mongoose = require("mongoose");

const schoolSchema = mongoose.Schema({
	ObjectID: {
		type: Number,
	},
	nazev: {
		type: String,
	},
	ico: {
		type: String,
	},
	zrizovatel: {
		type: String,
	},
	pravni_forma: {
		type: String,
	},
	redizo: {
		type: String,
	},
	izo: {
		type: String,
	},
	obor_nazev: {
		type: String,
	},
	obor_kod: {
		type: String,
	},
	nazev_svp_zamereni_oboru: {
		type: String,
	},
	vzdelavani_delka_roky: {
		type: Number,
	},
	zpusob_ukonceni_vzdelavani: {
		type: String,
	},
	pocet_prihl_1_kolo_prij_riz: {
		type: Number,
	},
	pocet_prij_1_kolo_prij_riz: {
		type: Number,
	},
	pocet_nabizenych_mist: {
		type: Number,
	},
	rocni_skolne: {
		type: Number,
	},
	prijimaci_zkouska: {
		type: String,
	},
	forma_vzdelavani: {
		type: String,
	},
	druh_vzdelavani: {
		type: String,
	},
	obor_urcen_pro_uchaz_s_uk_vzd: {
		type: String,
	},
	obor_vhodny_pro_ozp: {
		type: String,
	},
	povinna_lekarska_prohlidka: {
		type: String,
	},
	poznamka: {
		type: String,
	},
	nazev_vusc: {
		type: String,
	},
	kod_vusc: {
		type: String,
	},
	nazev_okresu: {
		type: String,
	},
	kod_okresu: {
		type: String,
	},
	nazev_orp: {
		type: String,
	},
	kod_orp: {
		type: String,
	},
	nazev_obce: {
		type: String,
	},
	kod_obce: {
		type: String,
	},
	nazev_ulice: {
		type: String,
	},
	cislo_domovni: {
		type: String,
	},
	typ_cisla_domovniho: {
		type: String,
	},
	cislo_orientacni: {
		type: String,
	},
	psc: {
		type: String,
	},
	www: {
		type: String,
	},
	wkt: {
		type: String,
	},
	x: {
		type: Number,
	},
	y: {
		type: Number,
	},
	dp_id: {
		type: String,
	},
});

module.exports = mongoose.model("Schools", schoolSchema);
